package com.stride.activity

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.time.TimeRangeFilter
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime

class HealthConnectRepository(private val context: Context) {
    companion object {
        const val PROVIDER_PACKAGE = "com.google.android.apps.healthdata"
        val stepsPermission: String = HealthPermission.getReadPermission(StepsRecord::class)
    }


    fun sdkStatus(): Int = HealthConnectClient.getSdkStatus(context, PROVIDER_PACKAGE)


    fun client(): HealthConnectClient = HealthConnectClient.getOrCreate(context)


    suspend fun hasStepsPermission(): Boolean = stepsPermission in client().permissionController.getGrantedPermissions()


    suspend fun todaySteps(): Long {
        val hc = client()
        val now = Instant.now()
        val start = ZonedDateTime.now(ZoneId.systemDefault()).toLocalDate().atStartOfDay(ZoneId.systemDefault()).toInstant()
        val result = hc.aggregate(
            AggregateRequest(
                metrics = setOf(StepsRecord.COUNT_TOTAL),
                timeRangeFilter = TimeRangeFilter.between(start, now)
            )
        )
        return result[StepsRecord.COUNT_TOTAL] ?: 0L
    }
}

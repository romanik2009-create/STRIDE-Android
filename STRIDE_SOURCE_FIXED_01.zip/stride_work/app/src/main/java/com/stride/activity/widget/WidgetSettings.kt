package com.stride.activity.widget

import android.content.Context

object WidgetSettings {
    const val KEY_METRICS = "metrics"
    const val KEY_STYLE = "style"
    const val KEY_ALPHA = "alpha"
    const val KEY_COMPACT = "compact"
    const val STYLE_GLASS = "GLASS"
    const val STYLE_SOLID = "SOLID"

    private fun prefs(context: Context, widgetId: Int) =
        context.getSharedPreferences("stride_widget_instance_$widgetId", Context.MODE_PRIVATE)



    fun metrics(context: Context, widgetId: Int): List<String> =
        prefs(context, widgetId).getString(KEY_METRICS, "DISTANCE,CALORIES,FLOORS")!!
            .split(',').filter { it.isNotBlank() }.distinct().take(4)

    fun saveMetrics(context: Context, widgetId: Int, metrics: List<String>) {
        prefs(context, widgetId).edit().putString(KEY_METRICS, metrics.distinct().take(4).joinToString(",")).apply()
    }

    fun style(context: Context, widgetId: Int) = prefs(context, widgetId).getString(KEY_STYLE, STYLE_GLASS) ?: STYLE_GLASS
    fun saveStyle(context: Context, widgetId: Int, style: String) = prefs(context, widgetId).edit().putString(KEY_STYLE, style).apply()
    fun alpha(context: Context, widgetId: Int) = prefs(context, widgetId).getInt(KEY_ALPHA, 88).coerceIn(20, 100)
    fun saveAlpha(context: Context, widgetId: Int, alpha: Int) = prefs(context, widgetId).edit().putInt(KEY_ALPHA, alpha.coerceIn(20, 100)).apply()
    fun compact(context: Context, widgetId: Int) = prefs(context, widgetId).getBoolean(KEY_COMPACT, false)
    fun saveCompact(context: Context, widgetId: Int, compact: Boolean) = prefs(context, widgetId).edit().putBoolean(KEY_COMPACT, compact).apply()

    fun metricLabel(metric: String): String = when (metric) {
        "DISTANCE" -> "DISTANCE"
        "CALORIES" -> "CALORIES"
        "FLOORS" -> "FLOORS"
        "ELEVATION" -> "ELEVATION"
        "ACTIVE_TIME" -> "ACTIVE TIME"
        else -> metric
    }
}

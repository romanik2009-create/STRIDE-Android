package com.stride.activity

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import kotlinx.coroutines.launch
import androidx.glance.appwidget.GlanceAppWidgetManager
import com.stride.activity.widget.StrideSmallWidget
import com.stride.activity.widget.StrideMediumWidget
import com.stride.activity.widget.StrideLargeWidget
import java.text.NumberFormat
import java.util.Locale

private val Night = Color(0xFF0B1016)
private val Glass = Color(0xFF18232D)
private val Mint = Color(0xFF83DFCE)
private val Muted = Color(0xFF9CAAB6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StrideHome() }
    }
}


@Composable
private fun StrideHome() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val repo = remember { HealthConnectRepository(context) }
    val scope = rememberCoroutineScope()
    var steps by remember { mutableStateOf<Long?>(null) }
    var status by remember { mutableStateOf("Проверяем Health Connect…") }
    var loading by remember { mutableStateOf(false) }
    var permissionGranted by remember { mutableStateOf(false) }
    var secondaryMetric by remember { mutableStateOf(context.getSharedPreferences("stride_widget", 0).getString("secondary_metric", "DISTANCE") ?: "DISTANCE") }
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = PermissionController.createRequestPermissionResultContract()
    ) { permissions ->
        permissionGranted = HealthConnectRepository.stepsPermission in permissions
        if (permissionGranted) {
            status = "Доступ к шагам разрешён"
            scope.launch { loadSteps(repo, { steps = it }, { status = it }, { loading = it }) }
        } else status = "Разрешение на шаги не предоставлено"
    }

    LaunchedEffect(Unit) {
        when (repo.sdkStatus()) {
            HealthConnectClient.SDK_AVAILABLE -> {
                status = "Health Connect доступен"
                loading = true
                try {
                    permissionGranted = repo.hasStepsPermission()
                    if (permissionGranted) steps = repo.todaySteps()
                    status = if (permissionGranted) "Данные синхронизированы" else "Подключите источник активности"
                } catch (e: Exception) {
                    status = "Не удалось получить данные. Проверьте разрешения."
                }
                loading = false
            }
            HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED -> status = "Установите или обновите Health Connect"
            else -> status = "Health Connect недоступен на этом устройстве"
        }
    }


    MaterialTheme {
        Column(
            Modifier.fillMaxSize().background(Night).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("STRIDE", color = Mint, fontSize = 12.sp, letterSpacing = 3.sp)
            Text("Activity intelligence", color = Color.White, fontSize = 25.sp)
            Card(colors = CardDefaults.cardColors(containerColor = Glass), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("TODAY'S STEPS", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp)
                    Text(steps?.let { NumberFormat.getIntegerInstance(Locale.US).format(it) } ?: "—", color = Color.White, fontSize = 38.sp)
                    Text("из 15 000 шагов", color = Mint, fontSize = 14.sp)
                    val progress = ((steps ?: 0L).toFloat() / 15_000f).coerceIn(0f, 1f)
                    LinearProgressIndicator(progress = { progress }, color = Mint, trackColor = Color.White.copy(alpha = .1f), modifier = Modifier.fillMaxWidth())
                    Text("${(progress * 100).toInt()}% цели", color = Muted, fontSize = 12.sp)
                }
            }
            Card(colors = CardDefaults.cardColors(containerColor = Glass), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("ПОДКЛЮЧЕНИЕ ДАННЫХ", color = Mint, fontSize = 11.sp, letterSpacing = 1.sp)
                    Text(status, color = Color.White, fontSize = 14.sp)
                    if (loading) LinearProgressIndicator(color = Mint, trackColor = Color.White.copy(alpha = .1f), modifier = Modifier.fillMaxWidth())
                    if (repo.sdkStatus() == HealthConnectClient.SDK_AVAILABLE && !permissionGranted) {
                        Button(onClick = { permissionLauncher.launch(setOf(HealthConnectRepository.stepsPermission)) }, colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Night)) {
                            Text("Подключить Health Connect")
                        }
                    } else if (permissionGranted) {
                        OutlinedButton(onClick = { scope.launch { loadSteps(repo, { steps = it }, { status = it }, { loading = it }) } }) {
                            Text("Обновить данные", color = Mint)
                        }
                    }
                }
            }
            Card(colors = CardDefaults.cardColors(containerColor = Glass), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("WIDGET STUDIO", color = Mint, fontSize = 11.sp, letterSpacing = 1.5.sp)
                    Text("Дополнительная метрика", color = Color.White, fontSize = 14.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("DISTANCE", "CALORIES", "FLOORS").forEach { metric ->
                            OutlinedButton(onClick = {
                                secondaryMetric = metric
                                context.getSharedPreferences("stride_widget", 0).edit().putString("secondary_metric", metric).apply()
                                scope.launch { refreshStrideWidgets(context) }
                            }, colors = ButtonDefaults.outlinedButtonColors(contentColor = if (secondaryMetric == metric) Mint else Muted)) {
                                Text(metric, fontSize = 10.sp)
                            }
                        }
                    }
                    Text("Выбор сохранён для виджетов. Значения дополнительных метрик подключим на следующем этапе.", color = Muted, fontSize = 11.sp)
                }
            }
            Text("STRIDE получает шаги через Health Connect. Показания могут обновляться с задержкой источника данных.", color = Muted, fontSize = 12.sp)
        }
    }
}


private suspend fun loadSteps(
    repo: HealthConnectRepository,
    onSteps: (Long) -> Unit,
    onStatus: (String) -> Unit,
    onLoading: (Boolean) -> Unit
) {
    onLoading(true)
    try {
        onSteps(repo.todaySteps())
        onStatus("Данные синхронизированы")
    } catch (e: Exception) {
        onStatus("Ошибка чтения шагов. Проверьте разрешение Health Connect.")
    } finally {
        onLoading(false)
    }
}


private suspend fun refreshStrideWidgets(context: android.content.Context) {
    val manager = GlanceAppWidgetManager(context)
    listOf(
        StrideSmallWidget() to StrideSmallWidget::class.java,
        StrideMediumWidget() to StrideMediumWidget::class.java,
        StrideLargeWidget() to StrideLargeWidget::class.java
    ).forEach { (widget, clazz) ->
        manager.getGlanceIds(clazz).forEach { id -> widget.update(context, id) }
    }
}

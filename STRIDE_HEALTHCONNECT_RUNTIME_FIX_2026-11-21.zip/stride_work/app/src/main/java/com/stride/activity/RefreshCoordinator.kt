package com.stride.activity

import java.util.concurrent.atomic.AtomicBoolean

/** Prevents overlapping Health Connect refreshes from lifecycle and UI events. */
internal class RefreshCoordinator {
    private val active = AtomicBoolean(false)

    fun tryStart(): Boolean = active.compareAndSet(false, true)

    fun finish() {
        active.set(false)
    }
}

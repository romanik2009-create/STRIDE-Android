package com.stride.activity

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RefreshCoordinatorTest {
    @Test
    fun onlyOneRefreshCanRunAtATimeAndGateReopensAfterFinish() {
        val coordinator = RefreshCoordinator()

        assertTrue(coordinator.tryStart())
        assertFalse(coordinator.tryStart())

        coordinator.finish()
        assertTrue(coordinator.tryStart())
        coordinator.finish()
    }
}

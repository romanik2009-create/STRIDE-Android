# STRIDE runtime stability fix — 2026-11-21

## Observed behavior
The supplied 9-second screen recording shows the home screen after permissions have been granted. The Refresh and Manage Access controls receive touch feedback, but the screen does not show a completed action or any step data. The recording does not contain Android logcat output, so it cannot by itself prove an ANR or a process crash.

## Code findings
- Initial `LaunchedEffect(Unit)` and the Activity `ON_RESUME` observer both started `refreshHealthConnect`.
- The permission-result callback started a separate `loadSteps` call and a widget refresh while the lifecycle observer could start another full refresh.
- `refreshHealthConnect` and nested `loadSteps` both changed the same `loading` flag, so one operation could hide the progress indicator while another was still running.
- The Manage Access button re-launched the same permission request contract rather than opening Health Connect's data-management UI.
- The main screen used a non-scrollable `Column`, and the progress indicator was conditionally inserted into the layout.

## Changes in this archive
- Added `RefreshCoordinator` to prevent overlapping refreshes triggered by lifecycle, permission result, initial composition, or user interaction.
- Centralized Health Connect reads through the same refresh path and made the outer refresh own the loading state.
- Added a 15-second Health Connect read timeout and a bounded widget-refresh timeout so loading cannot remain active indefinitely.
- Disabled Refresh / Manage Access while a request is in flight.
- Reserved progress-indicator height to prevent controls below it shifting vertically.
- Made the home screen vertically scrollable.
- Changed Manage Access to open `HealthConnectClient.getHealthConnectManageDataIntent(...)` (with settings intent fallback).
- Added a regression test for the single-flight refresh coordinator and expanded the manual test checklist.
- Retained the build fixes for `TotalCaloriesBurnedRecord.ENERGY_TOTAL` and the Glance `ComponentName` click action.

## Verification status
- RefreshCoordinator test harness: PASS (compiled with kotlinc 1.9.0 and ran successfully).
- ZIP integrity: to be checked after archive creation.
- Android Gradle build and on-device UI verification: NOT RUN in this environment; a successful GitHub Actions run is still required.

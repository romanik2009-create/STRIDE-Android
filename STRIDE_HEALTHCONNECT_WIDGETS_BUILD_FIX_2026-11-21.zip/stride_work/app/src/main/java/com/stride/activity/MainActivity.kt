package com.stride.activity

import android.os.Bundle
import android.content.Intent
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import kotlinx.coroutines.launch
import androidx.glance.appwidget.GlanceAppWidgetManager
import com.stride.activity.widget.StrideSmallWidget
import com.stride.activity.widget.StrideMediumWidget
import com.stride.activity.widget.StrideLargeWidget
import java.text.NumberFormat
import java.util.Locale

private val Night = Color(0xFF0B1016)
private val Glass = Color(0xFF18232D)
private val Mint = Color(0xFF83DFCE)
private val Muted = Color(0xFF9CAAB6)
private const val DAILY_GOAL = 15_000L


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StrideHome() }
    }
}


@Composable
private fun StrideHome() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val repo = remember { HealthConnectRepository(context) }
    val scope = rememberCoroutineScope()
    var steps by remember { mutableStateOf<Long?>(null) }
    var status by remember { mutableStateOf("Проверяем Health Connect…") }
    var loading by remember { mutableStateOf(false) }
    var permissionGranted by remember { mutableStateOf(false) }
    var sdkStatus by remember { mutableStateOf<Int?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = PermissionController.createRequestPermissionResultContract()
    ) { grantedPermissions ->
        permissionGranted = HealthConnectRepository.stepsPermission in grantedPermissions
        if (permissionGranted) {
            scope.launch {
                loadSteps(repo, { steps = it }, { status = it }, { loading = it }, { permissionGranted = it })
                refreshStrideWidgets(context)
            }
        } else {
            steps = null
            repo.clearHealthCache()
            status = "Разрешение на чтение шагов не предоставлено"
            scope.launch { refreshStrideWidgets(context) }
        }
    }


    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                scope.launch {
                    refreshHealthConnect(
                        repo = repo,
                        context = context,
                        onSdkStatus = { sdkStatus = it },
                        onPermission = { permissionGranted = it },
                        onSteps = { steps = it },
                        onStatus = { status = it },
                        onLoading = { loading = it }
                    )
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }


    LaunchedEffect(Unit) {
        refreshHealthConnect(
            repo = repo,
            context = context,
            onSdkStatus = { sdkStatus = it },
            onPermission = { permissionGranted = it },
            onSteps = { steps = it },
            onStatus = { status = it },
            onLoading = { loading = it }
        )
    }


    MaterialTheme(colorScheme = darkColorScheme(primary = Mint, background = Night, surface = Glass)) {
        Column(
            Modifier.fillMaxSize().background(Night).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("STRIDE", color = Mint, fontSize = 12.sp, letterSpacing = 3.sp)
            Text("Activity intelligence", color = Color.White, fontSize = 25.sp)
            Card(colors = CardDefaults.cardColors(containerColor = Glass), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("TODAY'S STEPS", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp)
                    Text(steps?.let { NumberFormat.getIntegerInstance(Locale.US).format(it) } ?: "—", color = Color.White, fontSize = 38.sp)
                    Text("из 15 000 шагов", color = Mint, fontSize = 14.sp)
                    if (steps != null) {
                        val progress = (steps!!.toFloat() / DAILY_GOAL).coerceIn(0f, 1f)
                        LinearProgressIndicator(progress = { progress }, color = Mint, trackColor = Color.White.copy(alpha = .1f), modifier = Modifier.fillMaxWidth())
                        Text("${(progress * 100).toInt()}% цели", color = Muted, fontSize = 12.sp)
                    } else {
                        Text("Прогресс появится после поступления данных за сегодня", color = Muted, fontSize = 12.sp)
                    }
                }
            }
            Card(colors = CardDefaults.cardColors(containerColor = Glass), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("ПОДКЛЮЧЕНИЕ ДАННЫХ", color = Mint, fontSize = 11.sp, letterSpacing = 1.sp)
                    Text(status, color = Color.White, fontSize = 14.sp)
                    if (loading) LinearProgressIndicator(color = Mint, trackColor = Color.White.copy(alpha = .1f), modifier = Modifier.fillMaxWidth())
                    if (sdkStatus == HealthConnectClient.SDK_AVAILABLE && !permissionGranted) {
                        Button(
                            onClick = { permissionLauncher.launch(HealthConnectRepository.readPermissions) },
                            colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Night)
                        ) { Text("Подключить Health Connect") }
                    } else if (permissionGranted) {
                        OutlinedButton(onClick = {
                            scope.launch {
                                loadSteps(repo, { steps = it }, { status = it }, { loading = it }, { permissionGranted = it })
                                refreshStrideWidgets(context)
                            }
                        }) { Text("Обновить данные", color = Mint) }
                        TextButton(onClick = { permissionLauncher.launch(HealthConnectRepository.readPermissions) }) {
                            Text("Управлять разрешениями и метриками", color = Mint)
                        }
                    }
                    if (sdkStatus == HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED) {
                        Button(onClick = { openHealthConnectStore(context) }, colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Night)) {
                            Text("Обновить Health Connect")
                        }
                    }
                }
            }
            Card(colors = CardDefaults.cardColors(containerColor = Glass), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("WIDGET STUDIO", color = Mint, fontSize = 11.sp, letterSpacing = 1.5.sp)
                    Text("Настройки сохраняются отдельно для каждого виджета", color = Color.White, fontSize = 14.sp)
                    Text("Добавь виджет STRIDE на домашний экран и нажми на него, чтобы открыть Widget Studio и изменить метрики, порядок, стиль, прозрачность и Compact Mode.", color = Muted, fontSize = 12.sp)
                }
            }
            Text("STRIDE читает шаги через Health Connect. Если за сегодня нет записей, данные остаются пустыми, а не подменяются нулём.", color = Muted, fontSize = 12.sp)
        }
    }
}


private fun openHealthConnectStore(context: android.content.Context) {
    val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${HealthConnectRepository.PROVIDER_PACKAGE}"))
    try {
        context.startActivity(marketIntent)
    } catch (_: Exception) {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=${HealthConnectRepository.PROVIDER_PACKAGE}")))
    }
}


private suspend fun refreshHealthConnect(
    repo: HealthConnectRepository,
    context: android.content.Context,
    onSdkStatus: (Int) -> Unit,
    onPermission: (Boolean) -> Unit,
    onSteps: (Long?) -> Unit,
    onStatus: (String) -> Unit,
    onLoading: (Boolean) -> Unit
) {
    onLoading(true)
    try {
        val status = repo.sdkStatus()
        onSdkStatus(status)
        when (status) {
            HealthConnectClient.SDK_AVAILABLE -> {
                val hasPermission = repo.hasStepsPermission()
                onPermission(hasPermission)
                if (hasPermission) {
                    loadSteps(repo, onSteps, onStatus, onLoading, onPermission)
                } else {
                    onSteps(null)
                    repo.clearHealthCache()
                    onStatus("Подключите источник активности и разрешите чтение шагов")
                }
            }
            HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED -> {
                onPermission(false)
                onSteps(null)
                repo.clearHealthCache()
                onStatus("Установите или обновите Health Connect")
            }
            else -> {
                onPermission(false)
                onSteps(null)
                repo.clearHealthCache()
                onStatus("Health Connect недоступен на этом устройстве")
            }
        }
    } catch (e: SecurityException) {
        onPermission(false)
        onSteps(null)
        repo.clearHealthCache()
        onStatus("Доступ Health Connect отозван. Подключите его заново.")
    } catch (e: Exception) {
        onSteps(null)
        onStatus("Не удалось проверить Health Connect. Попробуйте обновить данные.")
    } finally {
        onLoading(false)
        refreshStrideWidgets(context)
    }
}


private suspend fun loadSteps(
    repo: HealthConnectRepository,
    onSteps: (Long?) -> Unit,
    onStatus: (String) -> Unit,
    onLoading: (Boolean) -> Unit,
    onPermission: (Boolean) -> Unit
) {
    onLoading(true)
    try {
        val result = repo.todaySteps()
        onSteps(result)
        repo.cacheTodaySteps(result)
        val metrics = try { repo.todayMetrics() } catch (_: Exception) { emptyMap() }
        repo.cacheTodayMetrics(metrics)
        onStatus(if (result == null) "За сегодня пока нет данных Health Connect" else "Данные синхронизированы")
    } catch (e: SecurityException) {
        onPermission(false)
        onSteps(null)
        repo.clearHealthCache()
        onStatus("Доступ к шагам отозван. Подключите Health Connect заново.")
    } catch (e: Exception) {
        onSteps(null)
        onStatus("Ошибка чтения шагов. Проверьте Health Connect и повторите попытку.")
    } finally {
        onLoading(false)
    }
}


private suspend fun refreshStrideWidgets(context: android.content.Context) {
    val manager = GlanceAppWidgetManager(context)
    val widgets = listOf(
        StrideSmallWidget() to StrideSmallWidget::class.java,
        StrideMediumWidget() to StrideMediumWidget::class.java,
        StrideLargeWidget() to StrideLargeWidget::class.java
    )
    widgets.forEach { (widget, providerClass) ->
        try {
            manager.getGlanceIds(providerClass).forEach { id ->
                try { widget.update(context, id) } catch (_: Exception) { /* Keep other instances updating. */ }
            }
        } catch (_: Exception) { /* A missing provider or invalid ID should not block other widgets. */ }
    }
}

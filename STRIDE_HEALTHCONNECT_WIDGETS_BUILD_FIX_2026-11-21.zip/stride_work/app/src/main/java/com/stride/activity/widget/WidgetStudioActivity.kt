package com.stride.activity.widget

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.appwidget.GlanceAppWidgetManager
import kotlinx.coroutines.launch

private val studioBg = Color(0xFF0B1016)
private val studioPanel = Color(0xFF18232D)
private val studioMint = Color(0xFF83DFCE)
private val studioMuted = Color(0xFF9CAAB6)
private val availableMetrics = listOf("DISTANCE", "CALORIES", "FLOORS")
private enum class PreviewSize { SMALL, MEDIUM, LARGE }


class WidgetStudioActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val widgetId = intent.getIntExtra(android.appwidget.AppWidgetManager.EXTRA_APPWIDGET_ID, -1)
        if (widgetId == -1) {
            finish()
            return
        }
        setContent { StudioScreen(widgetId, onSaved = { finish() }) }
    }
}


@Composable
private fun StudioScreen(widgetId: Int, onSaved: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var metrics by remember { mutableStateOf(WidgetSettings.metrics(context, widgetId)) }
    var style by remember { mutableStateOf(WidgetSettings.style(context, widgetId)) }
    var alpha by remember { mutableFloatStateOf(WidgetSettings.alpha(context, widgetId).toFloat()) }
    var compact by remember { mutableStateOf(WidgetSettings.compact(context, widgetId)) }
    var previewSize by remember { mutableStateOf(PreviewSize.MEDIUM) }

    MaterialTheme(colorScheme = darkColorScheme(primary = studioMint, background = studioBg, surface = studioPanel)) {
        Column(
            Modifier.fillMaxSize().background(studioBg).padding(horizontal = 18.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("STRIDE", color = studioMint, style = MaterialTheme.typography.labelLarge)
            Text("Widget Studio", color = Color.White, style = MaterialTheme.typography.headlineMedium)
            Text("Widget #$widgetId · changes are preview-only until Save", color = studioMuted, style = MaterialTheme.typography.bodySmall)
            LivePreviewCard(metrics = metrics, style = style, alpha = alpha, compact = compact, size = previewSize)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                PreviewSize.values().forEach { size ->
                    FilterChip(
                        selected = previewSize == size,
                        onClick = { previewSize = size },
                        label = { Text(size.name) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            Column(
                Modifier.weight(1f, fill = false).fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(studioPanel).padding(14.dp)
            ) {
                Text("METRICS & ORDER", color = Color.White, style = MaterialTheme.typography.titleMedium)
                Text("Up to 3 metrics · arrows reorder live preview", color = studioMuted, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(6.dp))
                availableMetrics.forEach { metric ->
                    val selected = metric in metrics
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = selected,
                            onCheckedChange = { checked ->
                                metrics = when {
                                    checked && metrics.size < 3 -> metrics + metric
                                    !checked -> metrics - metric
                                    else -> metrics
                                }
                            }
                        )
                        Text(WidgetSettings.metricLabel(metric), color = Color.White, modifier = Modifier.weight(1f))
                        if (selected) {
                            Text("${metrics.indexOf(metric) + 1}", color = studioMint)
                            TextButton(onClick = {
                                val index = metrics.indexOf(metric)
                                if (index > 0) metrics = metrics.toMutableList().also { item ->
                                    val value = item.removeAt(index)
                                    item.add(index - 1, value)
                                }
                            }) { Text("↑", color = studioMint) }
                            TextButton(onClick = {
                                val index = metrics.indexOf(metric)
                                if (index >= 0 && index < metrics.lastIndex) metrics = metrics.toMutableList().also { item ->
                                    val value = item.removeAt(index)
                                    item.add(index + 1, value)
                                }
                            }) { Text("↓", color = studioMint) }
                        }
                    }
                }
            }
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(studioPanel).padding(14.dp)) {
                Text("APPEARANCE", color = Color.White, style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = style == WidgetSettings.STYLE_GLASS, onClick = { style = WidgetSettings.STYLE_GLASS }, label = { Text("Glass") })
                    FilterChip(selected = style == WidgetSettings.STYLE_SOLID, onClick = { style = WidgetSettings.STYLE_SOLID }, label = { Text("Solid") })
                }
                Text("Transparency · ${alpha.toInt()}%", color = Color.White)
                Slider(value = alpha, onValueChange = { alpha = it }, valueRange = 20f..100f, steps = 15)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Compact mode", color = Color.White, modifier = Modifier.weight(1f))
                    Switch(checked = compact, onCheckedChange = { compact = it })
                }
            }
            Button(
                onClick = {
                    WidgetSettings.saveMetrics(context, widgetId, metrics)
                    WidgetSettings.saveStyle(context, widgetId, style)
                    WidgetSettings.saveAlpha(context, widgetId, alpha.toInt())
                    WidgetSettings.saveCompact(context, widgetId, compact)
                    scope.launch {
                        try {
                            val manager = GlanceAppWidgetManager(context)
                            val widgetInfo = android.appwidget.AppWidgetManager.getInstance(context).getAppWidgetInfo(widgetId)
                            if (widgetInfo != null) {
                                val glanceId = manager.getGlanceIdBy(widgetId)
                                val providerClass = widgetInfo.provider.className
                                when {
                                    providerClass.endsWith("StrideSmallReceiver") -> StrideSmallWidget().update(context, glanceId)
                                    providerClass.endsWith("StrideMediumReceiver") -> StrideMediumWidget().update(context, glanceId)
                                    providerClass.endsWith("StrideLargeReceiver") -> StrideLargeWidget().update(context, glanceId)
                                }
                            }
                        } finally {
                            onSaved()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = studioMint, contentColor = studioBg)
            ) {
                Text("Save widget settings")
            }
        }
    }
}


@Composable
private fun LivePreviewCard(metrics: List<String>, style: String, alpha: Float, compact: Boolean, size: PreviewSize) {
    val isGlass = style == WidgetSettings.STYLE_GLASS
    val surfaceColor = if (isGlass) Color(0xFF1A2530).copy(alpha = alpha / 100f) else Color(0xFF1A2530)
    val shape = RoundedCornerShape(if (compact) 18.dp else 26.dp)
    val padding = if (compact) 12.dp else 18.dp
    val selectedMetrics = when (size) {
        PreviewSize.SMALL -> metrics.take(1)
        PreviewSize.MEDIUM -> metrics.take(2)
        PreviewSize.LARGE -> metrics.take(3)
    }

    Column(
        Modifier.fillMaxWidth().clip(shape).background(surfaceColor)
            .border(1.dp, Color.White.copy(alpha = if (isGlass) 0.12f else 0.05f), shape)
            .padding(padding)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("STRIDE", color = studioMint, fontSize = 12.sp)
            Spacer(Modifier.weight(1f))
            Text("SAMPLE PREVIEW · ${size.name}", color = studioMuted, fontSize = 9.sp)
        }
        Spacer(Modifier.height(if (compact) 5.dp else 10.dp))
        Text("STEPS", color = studioMuted, fontSize = 10.sp)
        Text("12,847", color = Color.White, fontSize = if (size == PreviewSize.SMALL) 27.sp else 34.sp, style = MaterialTheme.typography.headlineMedium)
        if (size != PreviewSize.SMALL && !compact) Text("of 15,000 goal", color = studioMuted, fontSize = 11.sp)
        Spacer(Modifier.height(6.dp))
        Box(Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF293844))) {
            Box(Modifier.fillMaxWidth(0.856f).fillMaxHeight().clip(RoundedCornerShape(8.dp)).background(studioMint))
        }
        if (size == PreviewSize.SMALL) {
            Spacer(Modifier.height(5.dp))
            Text("85% of daily goal", color = studioMint, fontSize = 11.sp)
            selectedMetrics.firstOrNull()?.let { metric ->
                Spacer(Modifier.height(3.dp))
                Text(WidgetSettings.metricLabel(metric), color = studioMuted, fontSize = 9.sp)
                Text(previewValue(metric), color = Color.White, fontSize = 13.sp, style = MaterialTheme.typography.titleMedium)
            }
        } else {
            Spacer(Modifier.height(if (compact) 6.dp else 10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                selectedMetrics.forEach { metric ->
                    Column(Modifier.weight(1f)) {
                        Text(WidgetSettings.metricLabel(metric), color = studioMuted, fontSize = 9.sp, maxLines = 1)
                        Text(previewValue(metric), color = Color.White, fontSize = if (compact) 12.sp else 15.sp, style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
            if (size == PreviewSize.LARGE && !compact) {
                Spacer(Modifier.height(8.dp))
                Text("ACTIVITY · HOURLY", color = studioMuted, fontSize = 9.sp)
                Row(Modifier.fillMaxWidth().height(36.dp), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.Bottom) {
                    listOf(0.25f, 0.4f, 0.3f, 0.56f, 0.44f, 0.78f, 0.6f, 0.9f, 0.52f, 0.7f, 0.34f, 0.86f).forEachIndexed { index, height ->
                        Box(Modifier.weight(1f).height((36 * height).dp).clip(RoundedCornerShape(3.dp)).background(if (index == 7) studioMint else Color(0xFF334552)))
                    }
                }
            }
        }
        Spacer(Modifier.height(5.dp))
        Text("Illustrative sample values · layout only", color = studioMuted, fontSize = 9.sp)
    }
}


private fun previewValue(metric: String): String = when (metric) {
    "DISTANCE" -> "9.42 km"
    "CALORIES" -> "524 kcal"
    "FLOORS" -> "18"
    "ELEVATION" -> "62 m"
    "ACTIVE_TIME" -> "86 min"
    else -> "—"
}

package com.stride.activity

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.TotalCaloriesBurnedRecord
import androidx.health.connect.client.records.FloorsClimbedRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.time.TimeRangeFilter
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Locale
import java.text.SimpleDateFormat
import java.util.Date

class HealthConnectRepository(private val context: Context) {
    companion object {
        const val PROVIDER_PACKAGE = "com.google.android.apps.healthdata"

        val stepsPermission: String = HealthPermission.getReadPermission(StepsRecord::class)
        val distancePermission: String = HealthPermission.getReadPermission(DistanceRecord::class)
        val caloriesPermission: String = HealthPermission.getReadPermission(TotalCaloriesBurnedRecord::class)
        val floorsPermission: String = HealthPermission.getReadPermission(FloorsClimbedRecord::class)
        val readPermissions: Set<String> = setOf(
            stepsPermission,
            distancePermission,
            caloriesPermission,
            floorsPermission
        )
    }


    fun sdkStatus(): Int = HealthConnectClient.getSdkStatus(context, PROVIDER_PACKAGE)


    fun client(): HealthConnectClient = HealthConnectClient.getOrCreate(context)


    suspend fun grantedPermissions(): Set<String> = client().permissionController.getGrantedPermissions()

    suspend fun hasStepsPermission(): Boolean = stepsPermission in grantedPermissions()


    private val cachePrefs by lazy { context.getSharedPreferences("stride_health_cache", Context.MODE_PRIVATE) }
    private fun todayKey(): String = ZonedDateTime.now(ZoneId.systemDefault()).toLocalDate().toString()

    fun cacheTodaySteps(steps: Long?) {
        val editor = cachePrefs.edit().putString("cache_day", todayKey()).putLong("last_sync", System.currentTimeMillis()).putBoolean("steps_present", steps != null)
        if (steps != null) editor.putLong("steps", steps) else editor.remove("steps")
        editor.apply()
    }

    fun cacheTodayMetrics(metrics: Map<String, String>) {
        val editor = cachePrefs.edit().putString("cache_day", todayKey()).putLong("last_sync", System.currentTimeMillis())
        listOf("DISTANCE", "CALORIES", "FLOORS").forEach { editor.remove("metric_$it") }
        metrics.filterKeys { it in setOf("DISTANCE", "CALORIES", "FLOORS") }.forEach { (key, value) ->
            editor.putString("metric_$key", value)
        }
        editor.apply()
    }

    fun cachedTodaySteps(): Long? {
        if (cachePrefs.getString("cache_day", null) != todayKey() || !cachePrefs.getBoolean("steps_present", false)) return null
        return if (cachePrefs.contains("steps")) cachePrefs.getLong("steps", 0L) else null
    }

    fun cachedTodayMetrics(): Map<String, String> {
        if (cachePrefs.getString("cache_day", null) != todayKey()) return emptyMap()
        return listOf("DISTANCE", "CALORIES", "FLOORS").mapNotNull { key ->
            cachePrefs.getString("metric_$key", null)?.let { key to it }
        }.toMap()
    }

    fun cachedSyncLabel(): String? {
        if (cachePrefs.getString("cache_day", null) != todayKey()) return null
        val syncedAt = cachePrefs.getLong("last_sync", 0L).takeIf { it > 0L } ?: return null
        return SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(syncedAt))
    }

    fun clearHealthCache() = cachePrefs.edit().clear().apply()


    private fun todayRange(): Pair<Instant, Instant> {
        val zone = ZoneId.systemDefault()
        val start = ZonedDateTime.now(zone).toLocalDate().atStartOfDay(zone).toInstant()
        return start to Instant.now()
    }


    /** Returns null when there is no aggregated step data for today, not a fabricated zero. */
    suspend fun todaySteps(): Long? {
        val hc = client()
        val (start, now) = todayRange()
        val result = hc.aggregate(
            AggregateRequest(
                metrics = setOf(StepsRecord.COUNT_TOTAL),
                timeRangeFilter = TimeRangeFilter.between(start, now)
            )
        )
        return result[StepsRecord.COUNT_TOTAL]
    }


    /** Only includes metrics the user granted and for which Health Connect returned a value. */
    suspend fun todayMetrics(): Map<String, String> {
        val hc = client()
        val granted = hc.permissionController.getGrantedPermissions()
        val requestedMetrics = buildSet {
            if (distancePermission in granted) add(DistanceRecord.DISTANCE_TOTAL)
            if (caloriesPermission in granted) add(TotalCaloriesBurnedRecord.ENERGY_TOTAL)
            if (floorsPermission in granted) add(FloorsClimbedRecord.FLOORS_CLIMBED_TOTAL)
        }
        if (requestedMetrics.isEmpty()) return emptyMap()

        val (start, now) = todayRange()
        val result = hc.aggregate(
            AggregateRequest(metrics = requestedMetrics, timeRangeFilter = TimeRangeFilter.between(start, now))
        )
        val values = mutableMapOf<String, String>()
        result[DistanceRecord.DISTANCE_TOTAL]?.let { distance ->
            values["DISTANCE"] = String.format(Locale.US, "%.2f km", distance.inMeters / 1000.0)
        }
        result[TotalCaloriesBurnedRecord.ENERGY_TOTAL]?.let { calories ->
            values["CALORIES"] = String.format(Locale.US, "%.0f kcal", calories.inKilocalories)
        }
        result[FloorsClimbedRecord.FLOORS_CLIMBED_TOTAL]?.let { floors ->
            values["FLOORS"] = String.format(Locale.US, "%.0f", floors)
        }
        return values
    }
}

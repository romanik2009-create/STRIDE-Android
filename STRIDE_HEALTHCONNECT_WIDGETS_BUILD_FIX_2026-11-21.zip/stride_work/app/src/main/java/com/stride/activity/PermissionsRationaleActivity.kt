package com.stride.activity

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Minimal in-app explanation shown from Health Connect's permission privacy link. */
class PermissionsRationaleActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(48, 48, 48, 48)
            setBackgroundColor(Color.rgb(11, 16, 22))
        }
        val title = TextView(this).apply {
            text = "STRIDE · Health Connect"
            textSize = 22f
            setTextColor(Color.rgb(131, 223, 206))
        }
        val explanation = TextView(this).apply {
            text = "STRIDE reads your daily step count from Health Connect to show activity progress. Distance, calories and floors are optional and are read only when you grant their permissions. Data is displayed in STRIDE and its launcher widgets; this version does not upload health readings to a STRIDE server. You can change or revoke access in Health Connect at any time."
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, 24, 0, 24)
        }
        val close = Button(this).apply {
            text = "Close"
            setOnClickListener { finish() }
        }
        container.addView(title)
        container.addView(explanation)
        container.addView(close)
        setContentView(container)
    }
}

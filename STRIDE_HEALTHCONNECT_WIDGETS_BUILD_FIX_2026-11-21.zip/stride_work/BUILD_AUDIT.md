# STRIDE Build Readiness Audit — v0.5


## Dependency alignment changes
- Android Gradle Plugin (AGP): 8.10.1
- Gradle runtime expected: 8.11.1 (AGP 8.10 line)
- Kotlin: 2.2.20
- Compose Compiler Gradle plugin: applied at the same Kotlin version
- Compose enabled through `android.buildFeatures.compose = true`
- Compose libraries aligned using Compose BOM 2025.01.00
- Java/Kotlin JVM target: 17
- compileSdk: 36
- targetSdk: 35 (kept conservative for launcher/widget behavior and Health Connect; revisit before release)
- Health Connect Client: 1.1.0
- Glance AppWidget: 1.1.1 (stable baseline)
- minSdk: 26

## Compatibility rationale
- Health Connect Client 1.1.0 requires compileSdk 36 and AGP 8.9.1 or higher; this project now satisfies those minimums.
- Kotlin 2.2.20 is paired with the Compose Compiler plugin 2.2.20.
- AGP 8.10.1 uses Gradle 8.11.1; Gradle is expected to run with JDK 17.
- Compose dependency versions are managed by a BOM instead of pinning `ui` and `material3` independently.

## Static checks performed in this package
- Source/project inventory review.
- Gradle plugin/dependency alignment edits.
- Manifest and Health Connect step-read permission reviewed against official docs.
- ZIP archive integrity check after packaging.

## Not verified
- Gradle dependency resolution (network access is not available in the authoring environment).
- Android compilation, D8/R8, resource merge, manifest merge, or APK packaging.
- Emulator/device install or runtime behavior.

## Build in Android Studio
1. Install Android Studio with JDK 17 (Android Studio's bundled JDK is recommended).
2. Install Android SDK Platform 36 and Build Tools using SDK Manager.
3. Open this project folder (the `stride_work` folder in the archive) and allow Gradle sync.
4. Use Gradle 8.11.1 if prompted/configured.
5. Run `:app:assembleDebug`.
6. If successful, APK path: `app/build/outputs/apk/debug/app-debug.apk`.

## Health Connect notes
- Step total uses `aggregate()` with `StepsRecord.COUNT_TOTAL` to avoid double-counting overlapping records.
- Permission is checked on each read; denied/revoked access is handled by the UI/widget fallback.
- Provider availability and install/update guidance should be refined before release.
- Health Connect reads are subject to permission and historical-access restrictions.

## Known remaining issues / release blockers
- The project has no Gradle Wrapper JAR because it could not be obtained in this environment. Build via Android Studio's Gradle installation, or add a standard Gradle wrapper when network access is available.
- Widget Studio/preview code still requires a full Android type-check and runtime validation.
- Widget data refresh scheduling, configuration intent flows, and launcher-specific resizing must be device-tested.
- Secondary metric values are placeholders and are not yet sourced from Health Connect.

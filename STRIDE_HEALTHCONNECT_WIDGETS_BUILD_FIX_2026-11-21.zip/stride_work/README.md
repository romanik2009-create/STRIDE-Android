# STRIDE Android — Widget Studio v1

Native Android starter for the STRIDE activity analytics app.

## Widget Studio v1 features
- Three home-screen widget providers: Small, Medium, Large.
- Each widget instance stores its own configuration in SharedPreferences keyed by the Android AppWidget ID.
- Metric selection (up to four): Distance, Calories, Floors, Elevation, Active Time.
- Metric ordering with up/down controls in the Widget Studio screen.
- Glass and Solid appearance presets.
- Adjustable Glass opacity (20–100%). Solid ignores opacity and stays opaque.
- Compact layout toggle.
- Tapping a widget opens its per-instance configuration screen.
- Configuration save refreshes only the widget provider instance that was edited.
- Steps are still read from Health Connect when permission is available.

## Build
Open the `stride_work` folder in Android Studio and let Gradle sync. This source ZIP has not been compiled in this environment; review compiler/API compatibility and run an Android build before installing.

## Current limitations
- Steps are the only live Health Connect metric implemented in this scaffold.
- Secondary metrics currently display an em dash placeholder until data readers are implemented.
- Activity bars are illustrative placeholder data.
- Widget styling is applied through Glance-supported surfaces; fine-grained blur/liquid-glass effects depend on launcher rendering support and are not native blur effects yet.
- A widget instance ID is used as its preference namespace so configurations do not bleed between widget instances.

## Widget Studio v1.1 — Live Preview Engine
- Interactive Small / Medium / Large preview size selector.
- Preview responds immediately to metric selection and metric ordering changes.
- Preview reflects Glass / Solid, transparency percentage, and compact mode before save.
- Preview values and hourly bars are intentionally mock-only; the native widget renderer still uses its own current data path.
- Save applies settings to the widget instance ID currently being configured.
- Build has not been verified with Android Gradle tooling in this environment.

## Build Readiness v0.5

The Gradle setup was aligned for Health Connect Client 1.1.0:
- AGP 8.10.1 / Kotlin 2.2.20 / Compose Compiler plugin 2.2.20
- Gradle 8.11.1 / JDK 17
- compileSdk 36 / targetSdk 35 / minSdk 26
- Compose BOM 2025.01.00
- Health Connect 1.1.0, Glance AppWidget 1.1.1

See `BUILD_AUDIT.md` for validation scope and limitations. This ZIP is not a compiled APK; no Android build ran in this environment.

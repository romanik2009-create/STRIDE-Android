# STRIDE — Health Connect and widgets manual verification


## Health Connect

- [ ] Provider installed and available: status changes to available.
- [ ] Provider absent: unavailable status is shown; app does not crash.
- [ ] Provider needs update: update-required status is shown; app does not try to read data.
- [ ] Connect flow: permission screen appears for declared step and optional metrics.
- [ ] Step permission granted: today's aggregate loads; progress is calculated against 15,000.
- [ ] Step permission denied: no steps/progress shown; connect action remains available.
- [ ] No records today: UI shows empty-data message, not `0`/`0%`.
- [ ] Permission revoked in Health Connect settings, then return to STRIDE: permission is rechecked, health cache cleared and widgets updated to blank/no-data state.
- [ ] Only Distance permission granted: distance is shown; calories/floors stay unavailable.
- [ ] Calories permission granted without records: calories is not fabricated as `0`.
- [ ] Floors permission granted without records: floors is not fabricated as `0`.
- [ ] Manual refresh updates displayed steps, metrics, cache and widgets.
- [ ] Midnight/time-zone boundary: today's range starts at local midnight, not UTC midnight.
- [ ] Permission-rationale link in Health Connect opens the STRIDE rationale activity/alias.

## Launcher widgets

- [ ] Add Small, Medium and Large STRIDE widgets.
- [ ] After opening STRIDE and refreshing, each widget updates from the local cache.
- [ ] No cache/no permission: widget shows blank placeholders, not invented totals.
- [ ] Small shows one selected metric's label/value when non-compact.
- [ ] Medium shows up to two configured metrics with values.
- [ ] Large shows up to three configured metrics with values; no fake hourly chart.
- [ ] Widget header shows cache sync time; stale previous-day cache is not displayed.
- [ ] Refresh data while app foregrounded: all widget instances refresh.

## Widget Studio

- [ ] Tapping a widget opens Widget Studio with that instance's ID.
- [ ] Two widgets can keep different metrics, order, appearance and compact mode.
- [ ] Metric checkbox changes and ↑/↓ order changes update preview.
- [ ] Preview is clearly marked as sample, not live health data.
- [ ] Save persists settings for only that widget and refreshes it.
- [ ] Glass/Solid, opacity slider and Compact Mode all persist after reopening.

# Build STRIDE Debug APK locally (Android Studio)

## 1. Install required tooling
- Install a current stable Android Studio.
- In Android Studio > Settings > Build, Execution, Deployment > Build Tools > Gradle, set **Gradle JDK = JDK 17** (download/install it from the IDE if needed).
- Open SDK Manager and install:
  - Android SDK Platform 36
  - Android SDK Build-Tools 36.0.0 (or the compatible installed version offered by SDK Manager)
  - Android SDK Platform-Tools

## 2. Open the project
1. Extract `STRIDE_BuildReady_v0.5.zip`.
2. Android Studio > **Open** > select the extracted `stride_work` project folder (the folder containing `settings.gradle.kts`).
3. Wait for Gradle sync. If sync fails, copy the full Build/Sync output.

## 3. Build APK
1. Select Build Variant: `debug`.
2. Run **Build > Build Bundle(s) / APK(s) > Build APK(s)**, or in the Android Studio terminal run:
   ```
   gradle --no-daemon :app:assembleDebug
   ```
3. If the build succeeds, APK location:
   `app/build/outputs/apk/debug/app-debug.apk`

## 4. If it fails
Send back the **complete first failure** from the Build window (starting at the first `FAILURE:` / `e:` / `error:` line and include the surrounding stack/details), plus Gradle Sync errors if there are any. Do not send only the final summary line.


## CI build through GitHub Actions
The project includes `.github/workflows/android-build.yml`. Upload the extracted project to a GitHub repository, push to `main` or `master`, or open Actions and run **Android Debug Build** via **Run workflow**. If successful, download the workflow artifact named `stride-debug-apk` containing `app-debug.apk`. If the workflow fails, open the failed job and copy the full first error section/log.

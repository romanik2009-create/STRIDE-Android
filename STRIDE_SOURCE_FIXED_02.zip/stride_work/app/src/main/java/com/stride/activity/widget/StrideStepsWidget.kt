package com.stride.activity.widget

import android.content.Context
import android.content.Intent
import android.content.ComponentName
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.action.actionStartActivity
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetManager
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.cornerRadius
import androidx.glance.background
import androidx.glance.action.clickable
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxHeight
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.stride.activity.HealthConnectRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.util.Locale

private val WidgetMint = ColorProvider(Color(0xFF83DFCE))
private val WidgetWhite = ColorProvider(Color(0xFFF4F7FA))
private val WidgetMuted = ColorProvider(Color(0xFF93A6B2))
private val Track = ColorProvider(Color(0xFF25343F))
private const val GOAL = 15_000L

enum class WidgetLayout { SMALL, MEDIUM, LARGE }


abstract class StrideBaseWidget(private val layout: WidgetLayout) : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val appWidgetId = GlanceAppWidgetManager(context).getAppWidgetId(id)
        val steps = withContext(Dispatchers.IO) {
            try {
                val repo = HealthConnectRepository(context)
                if (repo.hasStepsPermission()) repo.todaySteps() else null
            } catch (_: Exception) { null }
        }
        val number = steps?.let { NumberFormat.getIntegerInstance(Locale.US).format(it) } ?: "—"
        val percent = steps?.let { (it.toFloat() / GOAL).coerceIn(0f, 1f) } ?: 0f
        val metricOrder = WidgetSettings.metrics(context, appWidgetId)
        val style = WidgetSettings.style(context, appWidgetId)
        val opacity = WidgetSettings.alpha(context, appWidgetId)
        val compact = WidgetSettings.compact(context, appWidgetId)
        val glassAlpha = if (style == WidgetSettings.STYLE_GLASS) (opacity * 255 / 100) else 255
        val bg = ColorProvider(Color((glassAlpha shl 24) or 0x001A2530))
        val widgetPadding = if (compact) 9.dp else 14.dp
        val configIntent = Intent(context, WidgetStudioActivity::class.java).putExtra(android.appwidget.AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)

        provideContent {
            GlanceTheme {
                Column(
                    modifier = GlanceModifier.fillMaxSize().background(bg).cornerRadius(if (compact) 16.dp else 22.dp)
                        .clickable(actionStartActivity(ComponentName(context, WidgetStudioActivity::class.java))).padding(widgetPadding),
                    verticalAlignment = Alignment.Vertical.Top
                ) {
                    Row(modifier = GlanceModifier.fillMaxWidth()) {
                        Text("STRIDE", style = TextStyle(color = WidgetMint, fontWeight = FontWeight.Bold))
                        Spacer(modifier = GlanceModifier.width(8.dp))
                        Text("TODAY", style = TextStyle(color = WidgetMuted, fontSize = 11.sp))
                    }
                    Spacer(modifier = GlanceModifier.height(if (compact) 5.dp else 10.dp))
                    Text("STEPS", style = TextStyle(color = WidgetMuted, fontSize = 11.sp))
                    Text(number, style = TextStyle(color = WidgetWhite, fontSize = if (layout == WidgetLayout.SMALL) 25.sp else 30.sp, fontWeight = FontWeight.Bold))
                    if (layout != WidgetLayout.SMALL && !compact) Text("of 15,000 goal", style = TextStyle(color = WidgetMuted, fontSize = 12.sp))
                    Spacer(modifier = GlanceModifier.height(if (compact) 4.dp else 7.dp))
                    ProgressBar(percent)
                    if (layout == WidgetLayout.SMALL) {
                        Spacer(modifier = GlanceModifier.height(4.dp))
                        Text("${(percent * 100).toInt()}%", style = TextStyle(color = WidgetMint, fontSize = 12.sp))
                        if (!compact && metricOrder.isNotEmpty()) {
                            Spacer(modifier = GlanceModifier.height(4.dp))
                            Text(WidgetSettings.metricLabel(metricOrder.first()), style = TextStyle(color = WidgetMuted, fontSize = 9.sp))
                        }
                    } else {
                        Spacer(modifier = GlanceModifier.height(if (compact) 5.dp else 9.dp))
                        if (layout == WidgetLayout.MEDIUM) {
                            Row(modifier = GlanceModifier.fillMaxWidth()) {
                                MetricMini("GOAL", "${(percent * 100).toInt()}%")
                                Spacer(modifier = GlanceModifier.width(12.dp))
                                metricOrder.take(1).forEach { MetricMini(WidgetSettings.metricLabel(it), "—") }
                            }
                            if (metricOrder.size > 1 && !compact) {
                                Spacer(modifier = GlanceModifier.height(6.dp))
                                Text(WidgetSettings.metricLabel(metricOrder[1]), style = TextStyle(color = WidgetMuted, fontSize = 9.sp))
                            }
                        } else {
                            Row(modifier = GlanceModifier.fillMaxWidth()) {
                                MetricMini("GOAL", "${(percent * 100).toInt()}%")
                                Spacer(modifier = GlanceModifier.width(12.dp))
                                metricOrder.take(2).forEachIndexed { index, metric ->
                                    if (index > 0) Spacer(modifier = GlanceModifier.width(10.dp))
                                    MetricMini(WidgetSettings.metricLabel(metric), "—")
                                }
                            }
                            if (metricOrder.size > 2) {
                                Spacer(modifier = GlanceModifier.height(5.dp))
                                Text(metricOrder.drop(2).joinToString("  ·  ") { WidgetSettings.metricLabel(it) }, style = TextStyle(color = WidgetMuted, fontSize = 9.sp))
                            }
                            if (!compact) {
                                Spacer(modifier = GlanceModifier.height(8.dp))
                                Text("ACTIVITY", style = TextStyle(color = WidgetMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold))
                                Row(modifier = GlanceModifier.fillMaxWidth().height(26.dp), verticalAlignment = Alignment.Vertical.Bottom) {
                                    listOf(0.28f, 0.43f, 0.36f, 0.7f, 0.54f, 0.9f, percent).forEachIndexed { index, h ->
                                        Box(modifier = GlanceModifier.defaultWeight().fillMaxHeight().padding(horizontal = 2.dp)) {
                                            Box(modifier = GlanceModifier.width(14.dp).height((26 * h.coerceAtLeast(0.12f)).dp).background(if (index == 6) WidgetMint else Track).cornerRadius(3.dp)) {}
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

class StrideSmallWidget : StrideBaseWidget(WidgetLayout.SMALL)
class StrideMediumWidget : StrideBaseWidget(WidgetLayout.MEDIUM)
class StrideLargeWidget : StrideBaseWidget(WidgetLayout.LARGE)


@androidx.compose.runtime.Composable
private fun ProgressBar(progress: Float) {
    Box(modifier = GlanceModifier.fillMaxWidth().height(6.dp).background(Track).cornerRadius(4.dp)) {
        Box(modifier = GlanceModifier.fillMaxHeight().fillMaxWidth().width((progress * 300).dp).background(WidgetMint).cornerRadius(4.dp)) {}
    }
}
@androidx.compose.runtime.Composable
private fun MetricMini(label: String, value: String) {
    Column {
        Text(label, style = TextStyle(color = WidgetMuted, fontSize = 9.sp))
        Text(value, style = TextStyle(color = WidgetWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold))
    }
}

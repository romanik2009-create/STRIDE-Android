package com.stride.activity.widget

import android.content.Context
import android.content.Intent
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.action.actionStartActivity
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetManager
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.cornerRadius
import androidx.glance.background
import androidx.glance.action.clickable
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.stride.activity.HealthConnectRepository
import java.text.NumberFormat
import java.util.Locale

private val WidgetMint = ColorProvider(Color(0xFF83DFCE))
private val WidgetWhite = ColorProvider(Color(0xFFF4F7FA))
private val WidgetMuted = ColorProvider(Color(0xFF93A6B2))
private val Track = ColorProvider(Color(0xFF25343F))
private const val GOAL = 15_000L

enum class WidgetLayout { SMALL, MEDIUM, LARGE }


abstract class StrideBaseWidget(private val layout: WidgetLayout) : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val manager = GlanceAppWidgetManager(context)
        val appWidgetId = manager.getAppWidgetId(id)
        val repo = HealthConnectRepository(context)
        // Health Connect reads are performed while the app is foregrounded; widgets consume today's local cache.
        val steps = repo.cachedTodaySteps()
        val metricValues = repo.cachedTodayMetrics()
        val syncLabel = repo.cachedSyncLabel()?.let { "SYNC $it" } ?: "NO RECENT SYNC"
        val number = steps?.let { NumberFormat.getIntegerInstance(Locale.US).format(it) } ?: "—"
        val percent = steps?.let { (it.toFloat() / GOAL).coerceIn(0f, 1f) }
        val metricOrder = WidgetSettings.metrics(context, appWidgetId)
        val style = WidgetSettings.style(context, appWidgetId)
        val opacity = WidgetSettings.alpha(context, appWidgetId)
        val compact = WidgetSettings.compact(context, appWidgetId)
        val glassAlpha = if (style == WidgetSettings.STYLE_GLASS) (opacity * 255 / 100) else 255
        val bg = ColorProvider(Color((glassAlpha shl 24) or 0x001A2530))
        val widgetPadding = if (compact) 9.dp else 14.dp
        val fallbackWidth = when (layout) {
            WidgetLayout.SMALL -> 140f
            WidgetLayout.MEDIUM -> 210f
            WidgetLayout.LARGE -> 280f
        }
        val hostWidth = try {
            manager.getAppWidgetSizes(id).maxByOrNull { it.width.value }?.width?.value?.takeIf { it > 0f } ?: fallbackWidth
        } catch (_: Exception) {
            fallbackWidth
        }
        val progressWidth = (hostWidth - widgetPadding.value * 2).coerceAtLeast(48f).dp
        val configIntent = Intent(context, WidgetStudioActivity::class.java)
            .putExtra(android.appwidget.AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)

        provideContent {
            GlanceTheme {
                Column(
                    modifier = GlanceModifier.fillMaxSize().background(bg).cornerRadius(if (compact) 16.dp else 22.dp)
                        .clickable(actionStartActivity(configIntent)).padding(widgetPadding),
                    verticalAlignment = Alignment.Vertical.Top
                ) {
                    Row(modifier = GlanceModifier.fillMaxWidth()) {
                        Text("STRIDE", style = TextStyle(color = WidgetMint, fontWeight = FontWeight.Bold))
                        Spacer(modifier = GlanceModifier.width(8.dp))
                        Text(syncLabel, style = TextStyle(color = WidgetMuted, fontSize = 10.sp))
                    }
                    Spacer(modifier = GlanceModifier.height(if (compact) 5.dp else 10.dp))
                    Text("STEPS", style = TextStyle(color = WidgetMuted, fontSize = 11.sp))
                    Text(number, style = TextStyle(color = WidgetWhite, fontSize = if (layout == WidgetLayout.SMALL) 25.sp else 30.sp, fontWeight = FontWeight.Bold))
                    if (layout != WidgetLayout.SMALL && !compact) Text("of 15,000 goal", style = TextStyle(color = WidgetMuted, fontSize = 12.sp))
                    Spacer(modifier = GlanceModifier.height(if (compact) 4.dp else 7.dp))
                    // Do not render an empty-data state as a 0% progress bar.
                    percent?.let { ProgressBar(it, progressWidth) }

                    if (layout == WidgetLayout.SMALL) {
                        Spacer(modifier = GlanceModifier.height(4.dp))
                        Text(percent?.let { "${(it * 100).toInt()}%" } ?: "No data", style = TextStyle(color = WidgetMint, fontSize = 12.sp))
                        if (!compact && metricOrder.isNotEmpty()) {
                            Spacer(modifier = GlanceModifier.height(4.dp))
                            val metric = metricOrder.first()
                            Text(WidgetSettings.metricLabel(metric), style = TextStyle(color = WidgetMuted, fontSize = 9.sp))
                            Text(metricValues[metric] ?: "—", style = TextStyle(color = WidgetWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold))
                        }
                    } else {
                        Spacer(modifier = GlanceModifier.height(if (compact) 5.dp else 9.dp))
                        if (layout == WidgetLayout.MEDIUM) {
                            Row(modifier = GlanceModifier.fillMaxWidth()) {
                                MetricMini("GOAL", percent?.let { "${(it * 100).toInt()}%" } ?: "—")
                                Spacer(modifier = GlanceModifier.width(10.dp))
                                metricOrder.take(2).forEachIndexed { index, metric ->
                                    if (index > 0) Spacer(modifier = GlanceModifier.width(8.dp))
                                    MetricMini(WidgetSettings.metricLabel(metric), metricValues[metric] ?: "—")
                                }
                            }
                        } else {
                            Row(modifier = GlanceModifier.fillMaxWidth()) {
                                MetricMini("GOAL", percent?.let { "${(it * 100).toInt()}%" } ?: "—")
                                Spacer(modifier = GlanceModifier.width(12.dp))
                                metricOrder.take(2).forEachIndexed { index, metric ->
                                    if (index > 0) Spacer(modifier = GlanceModifier.width(10.dp))
                                    MetricMini(WidgetSettings.metricLabel(metric), metricValues[metric] ?: "—")
                                }
                            }
                            if (metricOrder.size > 2) {
                                Spacer(modifier = GlanceModifier.height(5.dp))
                                MetricMini(WidgetSettings.metricLabel(metricOrder[2]), metricValues[metricOrder[2]] ?: "—")
                            }
                            // The former large-widget activity bars were hard-coded mock data and are removed.
                        }
                    }
                }
            }
        }
    }
}


class StrideSmallWidget : StrideBaseWidget(WidgetLayout.SMALL)
class StrideMediumWidget : StrideBaseWidget(WidgetLayout.MEDIUM)
class StrideLargeWidget : StrideBaseWidget(WidgetLayout.LARGE)


@androidx.compose.runtime.Composable
private fun ProgressBar(progress: Float, maxWidth: Dp) {
    val safeProgress = progress.coerceIn(0f, 1f)
    Box(modifier = GlanceModifier.width(maxWidth).height(6.dp).background(Track).cornerRadius(4.dp)) {
        Box(modifier = GlanceModifier.width((maxWidth.value * safeProgress).dp).height(6.dp).background(WidgetMint).cornerRadius(4.dp)) {}
    }
}

@androidx.compose.runtime.Composable
private fun MetricMini(label: String, value: String) {
    Column {
        Text(label, style = TextStyle(color = WidgetMuted, fontSize = 9.sp))
        Text(value, style = TextStyle(color = WidgetWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold))
    }
}
